import game_globals
from game import *
