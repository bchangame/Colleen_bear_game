import pygame
import sys
# * means everything
# pygame.locals has global variables
from pygame.locals import *
from game_objects import *
from game_globals import *


class GAME(object):
    def __init__(self):
        self.surface = pygame.display.set_mode((W, H))
        pygame.init()
        pygame.display.set_caption("")

        self.background = Background(0, H - 1440 - GROUND, "test_background.png")
        self.character = Character(500, GROUND)
        self.character_size = self.character.size
        self.sheep = Item(720, GROUND, "Untitled.png", "sheep")
        self.sheep_heart = Item(720, GROUND, "sheep_heart.png", "sheep heart")
        self.knife = Item(500, GROUND, "Knife.png", "knife")
        self.tree = Item(0, GROUND, "tree.png", "tree")
        self.nest = Item(0, GROUND + 300, "Nest.png", "nest")
        self.feather = Item(self.nest.x, self.nest.y, "Feather.png", "feather")
        self.all_sprites = pygame.sprite.Group()
        self.inventory = Inventory(0, 0, "Inventory.png")
        self.all_sprites.add(self.sheep, self.knife, self.tree, self.nest, self.feather, self.character)
        self.inventory_sprite = pygame.sprite.Group()
        self.pause = False
        self.loops()

    def scroll(self, direction):
        if direction == "LEFT" and self.background.x <= (0 - SPEED):
            self.background.scroll_left()
            self.sheep.scroll_left()
            self.knife.scroll_left()
            self.sheep_heart.scroll_left()
            self.tree.scroll_left()
            self.nest.scroll_left()
            self.feather.scroll_left()
        elif direction == "RIGHT" and self.background.x >= (W - self.background.size[0] + SPEED):
            self.background.scroll_right()
            self.sheep.scroll_right()
            self.knife.scroll_right()
            self.sheep_heart.scroll_right()
            self.tree.scroll_right()
            self.nest.scroll_right()
            self.feather.scroll_right()

    def display_game(self):
        self.surface.blit(self.background.image, (self.background.x, self.background.y))
        for x in range(0, W, GROUND):
            self.surface.blit(pygame.image.load("Tile.png"), (x, H - GROUND))
        self.all_sprites.draw(self.surface)
        self.inventory_sprite.draw(self.surface)

        pygame.display.update()

    def display_inventory(self):
        self.inventory_sprite.add(self.inventory)
        for item in self.inventory.dictionary.keys():
            # figure out how many of the item we have
            # display item in open square
            # display a transparent box with number of items in it
            print("%s: %d" % (item.name, self.inventory.dictionary[item]))
            item.inventory_sprite.rect.y = 100
            item.inventory_sprite.rect.x = 850 + (150 * self.inventory.i)
            self.inventory_sprite.add(item.inventory_sprite)
            self.inventory.matrix.append((item, 100, 900 + (200 * self.inventory.i)))
            self.inventory.i += 1
        self.pause = True

    def dont_display_inventory(self):
        self.inventory_sprite.remove(self.inventory)
        for item in self.inventory.dictionary.keys():
            self.inventory_sprite.remove(item.inventory_sprite)
        self.pause = False
        self.inventory.i = 0

    def get_item(self, item):
        if item in self.inventory.dictionary.keys():
            self.inventory.dictionary[item] += 1
        else:
            self.inventory.dictionary[item] = 1

    def check_inventory(self, item):
        if item in self.inventory.dictionary.keys():
            return True
        else:
            return False

    def loops(self):
        while True:
            while not self.pause:
                self.surface.fill(WHITE)
                if self.character.climbing and not pygame.sprite.collide_mask(self.character, self.tree):
                    self.character.climbing = False
                for event in pygame.event.get():
                    if event.type == QUIT:
                        pygame.quit()
                        sys.exit(0)
                    if event.type == pygame.KEYDOWN:
                        if event.key == pygame.K_e:
                            self.display_inventory()
                        if event.key == pygame.K_p:
                            self.pause = True
                    if event.type == pygame.MOUSEBUTTONDOWN:
                        pos = pygame.mouse.get_pos()
                        if self.sheep_heart.rect.collidepoint(pos) and self.all_sprites.has(self.sheep_heart) and \
                                self.character.rect.colliderect(self.sheep_heart.rect):
                            self.get_item(self.sheep_heart)
                            self.all_sprites.remove(self.sheep_heart)
                        if self.knife.rect.collidepoint(pos) and self.all_sprites.has(self.knife) and self.character.rect.colliderect \
                                (self.knife.rect):
                            self.get_item(self.knife)
                            self.all_sprites.remove(self.knife)
                        if self.sheep.rect.collidepoint(pos) and self.check_inventory(self.knife) and self.all_sprites.has(self.sheep) and \
                                self.character.rect.colliderect(self.sheep.rect):
                            self.all_sprites.remove(self.sheep)
                            self.all_sprites.add(self.sheep_heart)
                keys = pygame.key.get_pressed()
                if not self.character.climbing:
                    self.character.falling()
                if keys[K_LEFT] or keys[K_a]:
                    self.character.move_left()
                    self.scroll("LEFT")
                if keys[K_RIGHT] or keys[K_d]:
                    self.character.move_right()
                    self.scroll("RIGHT")
                if keys[K_UP]:
                    if pygame.sprite.collide_mask(self.character, self.tree):
                        self.character.climb_up(2000)
                if keys[K_DOWN]:
                    if pygame.sprite.collide_mask(self.character, self.tree):
                        self.character.climb_down(GROUND)
                self.display_game()
            for event in pygame.event.get():
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_p:
                        self.pause = False
                    if event.key == pygame.K_e:
                        self.dont_display_inventory()
                if event.type == QUIT:
                    pygame.quit()
                    sys.exit(0)


GAME()
