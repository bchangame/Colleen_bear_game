import pygame
import sys
# * means everything
# pygame.locals has global variables
from pygame.locals import *
from game_globals import *


class Background(object):
    def __init__(self, init_x, init_y, image):
        self.x = init_x
        self.y = init_y
        self.image = pygame.image.load(image)
        self.size = self.image.get_rect().size
        self.rect = self.image.get_rect()

    def scroll_right(self):
        """This scrolls the background right when the character moves left."""
        self.x -= SPEED

    def scroll_left(self):
        """This scrolls the background left when the character moves right."""
        self.x += SPEED

# more classes


class Character(pygame.sprite.Sprite):
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)
        self.x = x
        # Loading function
        self.image = pygame.image.load("sulba_right.png").convert_alpha()
        self.mask = pygame.mask.from_surface(self.image)
        self.size = self.image.get_rect().size
        self.y = H - y - self.image.get_rect().height
        self.rect = self.image.get_rect(x = self.x, y = self.y)
        self.falling_speed = SPEED
        self.climbing = False

    def move_left(self):
        """This makes the character go faster than the background which is weird"""
        if self.x >= SPEED:
            self.x -= SPEED
            if not self.climbing:
                self.image = pygame.image.load("sulba_left.png").convert_alpha()
            # left facing sprite
            # animation
        self.rect = self.image.get_rect(x=self.x, y=self.y)

    def move_right(self):
        """This makes the character go faster than the background which is weird"""
        if self.x <= (W - self.size[0]):
            self.x += SPEED
            if not self.climbing:
                self.image = pygame.image.load("sulba_right.png").convert_alpha()
            # right facing sprite
        self.rect = self.image.get_rect(x=self.x, y=self.y)

    def jump(self):
        pass

    def climb_up(self, height):
        if self.y >= H - height + SPEED:
            self.climbing = True
            self.y -= SPEED
            self.image = pygame.image.load("sulba_climb.png").convert_alpha()
        self.rect = self.image.get_rect(x=self.x, y=self.y)

    def climb_down(self, ground):
        if self.rect.bottom <= H - ground - SPEED:
            self.climbing = True
            self.y += SPEED
            self.image = pygame.image.load("sulba_climb.png").convert_alpha()
        else:
            self.climbing = False
            self.image = pygame.image.load("sulba_right.png").convert_alpha()
        self.rect = self.image.get_rect(x=self.x, y=self.y)

    def falling(self):
        if self.rect.bottom <= H - GROUND - self.falling_speed:
            self.y += self.falling_speed
            self.falling_speed += 2
        else:
            self.y = H - GROUND - self.image.get_rect().height
        self.rect = self.image.get_rect(x=self.x, y=self.y)


''' Instructions for Object-Adding:
1. Make a new class as below
2. Next, instantiate an object of the class you made in game __init__
3. Add a scroll method to scroll
'''


class Item(pygame.sprite.Sprite):
    def __init__(self, x, y, image, name):
        pygame.sprite.Sprite.__init__(self)
        self.x = x
        self.image = pygame.image.load(image).convert_alpha()
        self.inventory_sprite = InventoryItem(0, 0, image)
        self.mask = pygame.mask.from_surface(self.image)
        self.y = H - y - self.image.get_rect().height
        self.name = name
        self.rect = self.image.get_rect(x = self.x, y = self.y)

    def scroll_right(self):
        """This makes other interactable objects scroll with the screen"""
        self.x -= SPEED
        self.rect = self.image.get_rect(x=self.x, y=self.y)

    def scroll_left(self):
        """This makes other interactable objects scroll with the screen"""
        self.x += SPEED
        self.rect = self.image.get_rect(x=self.x, y=self.y)


class Inventory(Item):
    def __init__(self, x, y, image):
        Item.__init__(self, x, y, image, "inventory")
        self.dictionary = {}
        self.i = 0
        self.matrix = []


class InventoryItem(pygame.sprite.Sprite):
    def __init__(self, x, y, image):
        pygame.sprite.Sprite.__init__(self)
        self.number = 0
        self.x = x
        self.y = y
        self.image = pygame.image.load(image).convert_alpha()
        self.rect = self.image.get_rect(x=self.x, y=self.y)


